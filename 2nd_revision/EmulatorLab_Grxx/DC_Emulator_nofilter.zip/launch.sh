#!/bin/sh

# Communication Tunnel
cd Tunnel
if( [[ `uname -r` == 4.19.0-xilinx-v2019.1 ]]); then 
insmod /lib/modules/4.19.0-xilinx-v2019.1/extra/TunnelKM.ko
else
insmod /lib/modules/4.9.0-xilinx-v2017.2/extra/TunnelKM.ko
fi

cd ..

# Signal Server
cd SignalServer
chmod 777 SiS_Linux_1_24_0_4641.out
nohup ./SiS_Linux_1_24_0_4641.out -c ../Config/Config.xml -p ../Config/Project.xml > /mnt/sd/sis.log &
cd ..

# DisplayHelper
sleep 8
chmod 777 UserInterface/$$DISPLAY_HELPER$$
nohup ./UserInterface/$$DISPLAY_HELPER$$ --project /mnt/ramdisk/Config/Project.xml --level developer > /dev/null &
